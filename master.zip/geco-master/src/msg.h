#ifndef MSG_H_INCLUDED
#define MSG_H_INCLUDED

#include "defs.h"

void ModelsExplanation(void);
void PrintMenu(void);
void PrintVersion(void);
void PrintExamples(void);

#endif

